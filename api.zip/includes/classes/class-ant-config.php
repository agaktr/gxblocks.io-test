<?php
/*!
 * @author		Sebastian Lutz
 * @copyright	Baebeca Solutions - Lutz
 * @email		lutz@baebeca.de
 * @pgp			0x5AD0240C
 * @link		https://www.baebeca.de
 * @link-github	https://github.com/Elompenta/antpool-php-api
 * @customer	-
 * @project		antpool-php-api
 * @license		GNU GENERAL PUBLIC LICENSE Version 2
 **/

class ant_config {

	// antpool user settings
	public $username 	= 'theok';
	public $api_key 	= '34e3ef60034340cb8d5b5e401d4ebba2';
	public $api_secret 	= 'ec4f138f894e4093906fb0677957820e';

	// alerts
	public  $email 		= '';
	public  $mobile 	= '';

}