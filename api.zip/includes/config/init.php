<?php 

define('__ROOT__', dirname(dirname(__FILE__)));
//Require the functions file having all the non class functions
require '../includes/config/functions.php';
?>