</div>
</div>


<div id="dl-back-to-top">#</div>
<div class="gxb-footer">

	<div class="gxb-footer-links">
		<a href="#">Terms of Use</a>
		<a href="#">Privacy Policy</a>
		<a href="#">EULA</a>
		<a href="#">Help</a>
	</div>
	
	<div class="gxb-developed-by">
		Designed and Developed by <a href="">Digital Lab</a>
	</div>
	
	<div class="gxb-copyright">
		<p>&copy; 2018 GX Blocks<p>
	</div>
	
	<div class="clearfix"></div>
	
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
<script src="../assets/js/global.js"></script>
<script src="../assets/js/Chart.js"></script>
 
</body>
</html>