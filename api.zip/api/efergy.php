<?php

// load classes
error_reporting(E_ALL);

class efergy {

	// configurations
	private $print_error_if_api_down = true;

	// private methods
	function __construct($api_key) {

		$this->api_key = $api_key;

		// todo: check if given data is correct

		if (!function_exists('curl_exec')) {
			exit("Error: Please install PHP curl extension to use this Software.\r\n $ apt-get install php5-curl\r\n");
		}
	}

	function __destruct() {
		unset($this->api_key);
	}

	function get($type, $options) {
		

		$ch = curl_init();
		
		$options_args = '';
		foreach ($options as $k=>$v){
			$options_args .= '&'.$k.'='.$v;
		}
		$api_url = 'http://www.energyhive.com/mobile_proxy/'.$type.'?'.$options_args.'&token='.$this->api_key;
	var_dump($api_url);
		// var_dump($api_url);
		curl_setopt($ch, CURLOPT_URL, $api_url);
		// curl_setopt($ch, CURLOPT_URL, 'http://www.energyhive.com/mobile_proxy/getTimeSeries?&fromTime='.strtotime('-5 days').'&toTime='.strtotime('-1 days').'&aggPeriod=day&aggFunc=sum&offset=0&token=1RA2g4QiGn-0t89yqlLFOd8e0OaffTsD');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		// set large timeout because API lak sometimes
		curl_setopt($ch, CURLOPT_TIMEOUT, 60);
		$result = curl_exec($ch);
		curl_close($ch);

		// check if curl was timed out
		if ($result === false) {
			if ($this->print_error_if_api_down) {
				exit('Error: No API connect');
			} else {
				exit();
			}
		}

		// validate JSON
		$result_json = json_decode($result);
		
		if (json_last_error() != JSON_ERROR_NONE) exit('Error: read broken JSON from API - JSON Error: '.json_last_error().' ('.$result.')');
		
		return $result_json;

	}

	function config($config, $value) {
		if (isset($this->$config)) {
			$this->$config = $value;
		}
	}
}


$energyhive = new efergy('Mh7yq4UKAJoivW5Zxl_pLUxbvZfS-NgG');

// $options = array();
// $results[] = $energyhive->get('getCurrentValuesSummary',$options);

// $options = array(
	// 'fromTime'	=>	strtotime('-30 days'),
	// 'toTime'	=>	strtotime('today'),
	// 'aggPeriod'	=>	'day',
	// 'aggFunc'	=>	'sum',
	// 'offset'	=>	0,
// );
// $results[] = $energyhive->get('getTimeSeries',$options);

// foreach ($results[0]->data as $k=>$maybe){
	
	// foreach($maybe->data as $nope=>$sensor){
		// var_dump();
		// var_dump(date('Y-M-d',intval(substr(key($k),0,-3))));
		// $value = $maybe;
		// var_dump($value);
		// echo '<br>';
	// }
	// echo '<br>';
	
	
// }



// $options = array(
	// 'fromTime'	=>	strtotime('-30 days'),
	// 'toTime'	=>	strtotime('today'),
	// 'period'	=>	'custom',
	// 'aggPeriod'	=>	'day',
	// 'aggFunc'	=>	'sum',
	// 'offset'	=>	0,
// );
// $results[] = $energyhive->get('getEnergy',$options);

// foreach ($results[0]->data as $k=>$maybe){
	

		// var_dump(date('Y-M-d',intval(substr(key($k),0,-3))));
		// $value = $maybe;
		// var_dump($value);
		// echo '<br>';

	// echo '<br>';
	
	
// }

$options = array(
	'fromTime'	=>	strtotime('-31 days'),
	'toTime'	=>	strtotime('+1 days'),
	'period'	=>	'custom',
	'aggPeriod'	=>	'day',
	'aggFunc'	=>	'sum',
	'type'		=>	'PWER',
	'offset'	=>	0,
);
$results[] = $energyhive->get('getHV',$options);

$encoded_result = json_encode($results[0]);

// foreach ($results[0]->data as $k=>$maybe){
	
	// foreach($maybe->data as $nope=>$sensor){
// var_dump($maybe->sid);
		// var_dump(date('Y-M-d',intval(substr(key($sensor),0,-3))));
		// $value = key($sensor);
		// var_dump($sensor->$value);
		// echo '<br>';
	// }
	// echo '<br>';
	
	
// }



//mysql cred
$servername = "212.24.104.75";
$username = "gxblocks_user";
$password = "enaskwdikos28";
$dbname = "gxblocks_data";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

//Insert to db
$the_insert = '';


$sql = "INSERT INTO energy_data (time, energy_response) VALUES (".time().",'".$encoded_result."')";

echo '</br>Importing</br>';
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>