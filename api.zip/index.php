<?php

//Require the init file responsible for loading all the required files.
require './includes/config/init.php';

get_header();
get_footer();
 ?>